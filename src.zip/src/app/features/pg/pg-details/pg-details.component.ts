import { Component } from '@angular/core';

@Component({
  selector: 'app-pg-details',
  standalone: true,
  imports: [],
  templateUrl: './pg-details.component.html',
  styleUrl: './pg-details.component.css'
})
export class PgDetailsComponent {

}
