import { Component } from '@angular/core';

@Component({
  selector: 'app-pg-list',
  standalone: true,
  imports: [],
  templateUrl: './pg-list.component.html',
  styleUrl: './pg-list.component.css'
})
export class PgListComponent {

}
