import { Component } from '@angular/core';

@Component({
  selector: 'app-add-pg',
  standalone: true,
  imports: [],
  templateUrl: './add-pg.component.html',
  styleUrl: './add-pg.component.css'
})
export class AddPgComponent {

}
