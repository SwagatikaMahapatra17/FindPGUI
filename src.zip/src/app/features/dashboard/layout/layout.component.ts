import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent implements OnInit{
constructor(private router: Router) {}
role: string | null = '';
username: string | null = '';

ngOnInit() {
  this.role = localStorage.getItem('role');
  this.username = 'User Name'; // from API later
}

logout() {
  localStorage.clear();  
  this.router.navigate(['/login']);
}
}
