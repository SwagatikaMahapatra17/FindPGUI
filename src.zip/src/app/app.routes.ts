import { Routes } from '@angular/router';
import path from 'path';
import { LayoutComponent } from './features/dashboard/layout/layout.component';
import { Component } from '@angular/core';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { CpagesComponent } from './features/dashboard/cpages/cpages.component';
import { CNavbarComponent } from './features/dashboard/cnavbar/cnavbar.component';
import { LoginComponent } from './features/login/login.component';
import { SignupComponent } from './features/signup/signup.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [   
    
    {
     path: '',
    redirectTo: 'auth/login',
    pathMatch: 'full'
  },
  {
    path: 'auth',
    loadChildren: () =>
      import('./features/dashboard/auth.module').then(m => m.AuthModule)
  },
{
    path: 'pg',
    loadChildren: () =>
      import('./features/pg/pg.module').then(m => m.PgModule)
  },
{
    path: 'dashboard',
    loadChildren: () =>
      import('./features/dashboard/dashboard.module').then(m => m.DashboardModule),
    canActivate: [authGuard]
  },
  
{
    path: 'booking',
    loadChildren: () =>
      import('./features/booking/booking.module').then(m => m.BookingModule)
  },


    // {
    //     path: '', component: HomeComponent, title: 'FIND PG'
    // },
    // {
    //     path: 'home', component: HomeComponent,
    // },
    // {
    //     path: 'about-us', component: AboutUsComponent,
    // },
    // {
    //     path: 'login', component: LoginComponent,
    // },
    // {
    //     path: 'signUp', component: SignupComponent,
    // },
    // {
    //     path: 'dashboard', children: [{
    //         path: "", component: DashboardComponent,
    //     },
    //     {
    //         path: 'cnavbar',
    //         component: CNavbarComponent,
    //     },
    //     ]
    // },
    // {
    //     path: 'layout', component: LayoutComponent,
    // }
];
