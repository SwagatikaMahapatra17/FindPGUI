import { Component } from '@angular/core';

@Component({
  selector: 'app-pg-card',
  standalone: true,
  imports: [],
  templateUrl: './pg-card.component.html',
  styleUrl: './pg-card.component.css'
})
export class PgCardComponent {

}
